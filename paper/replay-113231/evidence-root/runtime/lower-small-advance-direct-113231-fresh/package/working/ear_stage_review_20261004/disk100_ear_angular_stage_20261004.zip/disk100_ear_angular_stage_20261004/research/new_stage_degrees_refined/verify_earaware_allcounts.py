#!/usr/bin/env python3
"""Exact, conditional B=33 degree/angle support certificate.
No floats enter any acceptance decision; only stdlib plus sibling exact interval helper.
"""
from fractions import Fraction as Q
from pathlib import Path
import sys,json
from functools import lru_cache
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'coupled_edges'))
from verify_support import I,PI,sin,cos,asin
R=Q(113081,1000000); B=33; K=Q(6,25); T1=Q(3,100)
A=3*I(3).sqrt()/4; CA=I(Q(3,4)); ANG=PI/3

def imax(a,b):return I(max(a.a,b.a),max(a.b,b.b))
@lru_cache(maxsize=None)
def C(lam):
 assert K-3<lam<2
 y=(-(1-K)+I((1-K)*(1-K)+32-16*lam).sqrt())/8
 x=(1-y*y).sqrt()
 assert 0<y.a<y.b<1 and 0<x.a<x.b<1
 support=x*(1+2*y)+lam*asin(x)-K*x
 # Concavity of G_lam proves this upper support for the acute endpoint.
 # The obtuse endpoint minus K*x <= 1+max(0,lam*pi).
 return imax(support,1+imax(I(0),lam*PI))

def check_boundary():
 t0=PI/B;s=sin(t0);cc=cos(t0);h=(R*R-s*s).sqrt()
 sineta=s*(cc-h)/R;coseta=(h*cc+s*s)/R
 b=R*R*K*coseta
 assert b.b<R*R
 tc=asin(I(R)*I(K).sqrt());assert T1<tc.a<tc.b<t0.a
 s1=sin(T1);c1=cos(T1);h1=(R*R-s1*s1).sqrt()
 F0=s*h+t0-s*cc+b*(asin(s/R)-t0)
 FD0=cc*(R*R-2*s*s)/h+2*s*s+b*(cc/h-1)
 F1=s1*h1+T1-s1*c1+b*(asin(s1/R)-T1)
 FD1=c1*(R*R-2*s1*s1)/h1+2*s1*s1+b*(c1/h1-1)
 u=s1/R;v=(1-u*u).sqrt()
 P1=2*R*R*v*(K-u*u)
 PD1=2*R*u*c1*(3*u*u-K-2)/v
 aa=F0-t0*FD0-F1-P1+T1*(FD1+PD1)
 zz=FD0-FD1-PD1
 margins=[aa,aa+tc*zz]
 assert all(m.a>0 for m in margins)
 baseline=(198-2*B)*A*R*R+B*R*R*(C(Q(0))+K*sineta)+B*(s*h+t0-s*cc)
 return baseline,margins

def verify_ear_bound():
 # All-three-boundary-center q2 face: normalized area <= w, also <=t.
 w=(1-(1-2*I(R)).sqrt())/R
 assert w.b<Q(213,200)
 cutoff=Q(103,100);M=Q(179,100)
 small=I(2-K) # 0<=t<=1: t-k sqrt(t)<=1-k, anchors <=1
 middle=I(cutoff+1-K) # 1<=t<=cutoff
 large=w+1-K*(1+I(cutoff-1).sqrt())
 assert small.b<=M and middle.b==M and large.b<M
 return {'M2_upper':[M.numerator,M.denominator],'slab_width_over_radius':w.enc(),'t_cutoff':[cutoff.numerator,cutoff.denominator],'small_t_score_bound':small.enc(),'middle_t_score_bound':middle.enc(),'large_t_score_bound':large.enc()}

def verify():
 assert B in range(32,36) and K==Q(6,25) and 0<R<Q(1,5)
 assert CA.a==CA.b==Q(3,4)
 LVLO=Q(-19,100);LVHI=Q(1,20);L=LVHI-LVLO
 assert L==Q(6,25) and CA.b*CA.b<=1-(Q(1,2)+2*L/3)*(Q(1,2)+2*L/3)
 records=json.loads(Path(__file__).with_name('rational_potentials.json').read_text())
 assert len(records)==3, 'all three branches required'
 baseline,margins=check_boundary();ear=verify_ear_bound();rows=[]
 choices=[(Q(0),22,'U <= 22'),(Q(19,500),23,'U = 23'),(Q(19,250),24,'U >= 24')]
 for raw,(lb,U,branch) in zip(records,choices):
  assert Q(raw['lambda_boundary'])==lb and LVLO<=-lb<=LVHI
  beta=Q(raw['beta_numerator'],1000000);eta=Q(raw['eta_numerator'],1000000)
  table={(v['q'],v['d']):Q(v['lambda_numerator'],1000000) for v in raw['potentials']}
  expected={(q,d) for q in range(4) for d in range(max(3,q+1),100)}
  assert set(table)==expected and len(table)==len(raw['potentials'])
  audits=[]
  for q,d in sorted(expected):
   n=d-q;lv=table[q,d]
   assert n>0 and LVLO<=lv<=LVHI
   val=q*(C(lv+lb)-C(Q(0)))-lv*(6-d+q)*ANG+n*lv*lv/(4*CA)
   gap=beta*q+eta*(d-6)-val
   assert gap.a>=0,(branch,q,d,gap.enc())
   audits.append({'q':q,'d':d,'lambda_vertex':[lv.numerator,lv.denominator],'support_slack':gap.enc()})
  ear_coefficient=A-2*C(Q(0))+Q(179,100)-2*beta+eta+lb*PI
  assert ear_coefficient.b<0, (branch,ear_coefficient.enc())
  gain=B*beta+eta*(B-6-U)-lb*(2*PI+U*ANG)+U*lb*lb/(4*CA)
  coefficient=-eta-lb*ANG+lb*lb/(4*CA)
  if branch=='U <= 22':assert coefficient.a>0
  elif branch=='U >= 24':assert coefficient.b<0
  else:assert U==23
  deficit=PI-(baseline+R*R*gain)
  assert deficit.a>0,(branch,deficit.enc())
  rows.append({'branch':branch,'worst_integer_U':U,'lambda_boundary':[lb.numerator,lb.denominator],'beta':[beta.numerator,beta.denominator],'eta':[eta.numerator,eta.denominator],'U_coefficient':coefficient.enc(),'area_deficit':deficit.enc(),'per_ear_coefficient':ear_coefficient.enc(),'vertex_supports':audits})
 return {'status':'PASS','radius':[R.numerator,R.denominator],'B':B,'m_max':100,'q2_ears_allowed':True,'ear_bound':ear,'localized_support_constant':[3,4],'corner_coefficient_interval':[[-19,100],[1,20]],'baseline_excess':(baseline-PI).enc(),'short_arc_support_margins':[m.enc() for m in margins],'branches':rows,'scope':'Conditional on the full-angle-simplex Jensen-refined localized support lemma at coefficient range<=6/25; a straight Delaunay triangulated disk with m<=100,B as recorded, no q1 marked face with three boundary vertices, and each interior vertex incident to at most three ordinary marked faces. All q2 boundary ears and unmarked all-boundary faces are allowed. Higher-radius structural prerequisites must be independently proved. Not a full global lower bound by itself or exact optimum.'}

if __name__=='__main__':
 results=[]
 for B in range(32,36):
  row=verify();results.append(row)
  print('PASS ear-aware B',B,'deficits',*[float(Q(*x['area_deficit'][0])) for x in row['branches']], 'earcoeff',*[float(Q(*x['per_ear_coefficient'][1])) for x in row['branches']])
 Path(__file__).with_name('earaware_allcounts_certificate.json').write_text(json.dumps({'status':'PASS','cases':results},indent=2)+'\n')
