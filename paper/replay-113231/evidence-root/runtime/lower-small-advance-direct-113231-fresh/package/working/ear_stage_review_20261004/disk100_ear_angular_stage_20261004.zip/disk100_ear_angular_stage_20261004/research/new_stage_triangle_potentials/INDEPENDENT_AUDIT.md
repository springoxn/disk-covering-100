# Independent audit of the global three-corner potential support

The final proof is correct as a support inequality on the whole closed angle simplex. No mathematical gap was found. In particular, the stronger coefficient is derived at the global score maximizer and then bounds all scores; it is not applied as a stronger area loss to every actual triangle.

Audited final hashes:

* `PROOF.md`: `f63ca466126527dd2f6e2b32061e3f539de6fab0161d125fc7875e5b85b111c8`.
* `verify_localization.py`: `225dbe2a60eb751debd60c3993b8766c38b1df4a2d325860aa81a3b492bc8bce`.

An independent standard-library import and `verify()` run passed and agrees exactly with the saved original certificate. Actual rational output and log are saved in `independent_certificate.json` and `independent.log`. Additional guard tests are in `independent_negative_checks.json`; none modifies the original proof or checker.

## Nonacute exclusion on the whole simplex

For three deviations summing to zero, the sum of the positive entries equals the largest absolute entry. Subtracting the smallest potential therefore bounds its linear contribution by `L max(max alpha-pi/3, pi/3-min alpha)`. This is valid for arbitrary common shifts and real coefficients of range L.

For the positive-deviation case, fixed largest angle theta>=pi/2 gives `f<=sin(theta)(1+cos(theta))`. Its score derivative is `2u^2+u-1+L`, where u=cos(theta). For `0<L<=1/2` the unique root in [-1,0] is a minimum in theta; the maximum is at an endpoint. For L=0 the root is u=-1 at the endpoint and the function is decreasing. Both endpoint scores are below A by the certified strict margins.

For the negative-deviation case, the smallest angle t<=pi/4 and a nonacute angle theta lie in `pi/2<=theta<=pi-t`. The product derivative `sin(2theta+t)` is nonpositive throughout this interval, so `f<=sin(2t)`. The tangent of sin(2t) at pi/6 and the positive coefficient 1-L give the stated bound `sqrt(3)/2+pi(1+L)/12<=sqrt(3)/2+pi/8<A`.

Every degenerate boundary triple is nonacute. Since the equilateral score equals A, all nonacute and degenerate triples are strictly excluded from the global maximizer set, including the limiting range L=1/2.

## Identity, uniqueness and the multiplier bracket

On the angle-sum plane, the identity `sum sin(2alpha)=4 product sin(alpha)` follows by adding the first two sine terms and using `alpha_3=pi-alpha_1-alpha_2`. Hence the tangent Hessian is exactly `-2 sum sin(2alpha_i) v_i^2`. The acute portion of the simplex is convex, and this Hessian is strictly negative for nonzero tangent vectors. The localized global maximizer is therefore unique.

Centering the potentials gives the correct stationary equations `cos(2alpha_i)+mu_i=nu`. At `nu=-1/2+min mu`, all arccos arguments lie in [-1,-1/2], and their sum is at least 2pi. At `nu=-1/2+max mu`, all arguments lie in [-1/2,0], and their sum is at most 2pi. These closed-domain statements hold whenever L<=1/2. The sum is strictly decreasing, proving the root bracket and the cosine range `[-1/2-L,-1/2+L]`. A common potential is immaterial because angle deviations sum to zero.

## Why the local curvature gives a global support

For L<1/2 the maximizing angles and pi/3 all lie in the displayed closed interval. The segment between them stays there, so sin(2alpha_i)>=c_L on that whole segment. Integrating the exact Hessian gives `f(max)<=A-c_L||alpha(max)-pi/3||^2`, with zero tangent first derivative at equilateral. Completing the square bounds the *maximum linear score* by `A+||mu||^2/(4c_L)`. All other triangles, including obtuse and degenerate ones, have score at most this global maximum. This establishes the claimed whole-simplex support without asserting the false stronger actual-angle quadratic bound.

For L<=1/10 the exact uniform coefficient is c=4/5 and the penalty is `(5/16)||mu||^2`. The weaker uncentered norm is justified by `||mu||^2=||lambda||^2-3 bar(lambda)^2`. At L=1/2, only the acute-maximizer conclusion is used; the positive-curvature division is explicitly forbidden.

## Numerical certificate and revisions

The final checker is standalone and uses outward rational intervals, integer square-root enclosures and alternating Machin bounds. It now checks actual polynomial endpoint values and the derivative vertex, rather than a tautological coefficient equality present in the first version inspected. The L=0 endpoint wording in the proof was also repaired. Both revisions were independently inspected before the final rerun.

Five independent negative tests reject excessive range, zero-curvature quadratic use, floating coefficients, integer coefficients and the wrong number of corners. A huge common shift `10^20` is accepted with centered coefficients exactly zero. Range exactly 1/2 is accepted for localization and rejected for a positive quadratic support request. Source and proof hashes remained unchanged during this run.

This lemma supplies an area-plus-linear-angle support, not a covering-radius bound. A covering proof still needs a consistent potential assignment, one application per face, exact incidence sums, penalty accounting and same-radius geometry. No stronger radius or full optimality claim is made here.
