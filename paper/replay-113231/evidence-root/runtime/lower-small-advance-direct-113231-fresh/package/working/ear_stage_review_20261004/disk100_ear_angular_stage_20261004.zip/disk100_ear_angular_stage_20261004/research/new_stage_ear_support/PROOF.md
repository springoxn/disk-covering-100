# A marked two-edge support and an ear-aware angular budget

This is a local analytic extension. It does not establish a new covering radius. Its purpose is to allow genuine boundary ears in the angle-potential proof instead of requiring their separate exclusion.

## Two marked edges with a common length potential

Normalize the circumradius bound to one. Let the half-squared edge lengths be z1,z2,z3 in [0,1], and mark edges 1,2. Put t=z1+z2, p=z1*z2 and z=z3. If Delta is the triangle area, Heron and the circumradius formula give

Delta^2=4p-(t-z)^2, and 4pz<=Delta^2.

Consequently z<=2t-t^2, and 0<=t<=2. As in the original joint-triangle proof, Delta<=t on [0,1], while Delta<=t*sqrt(2t-t^2) on [1,2]. The anchor contribution for marked edge i is sqrt(zi*(1-zi)). For a common potential 0<=k<=1 subtract k*(sqrt(z1)+sqrt(z2)).

The function h_k(z)=sqrt(z*(1-z))-k*sqrt(z) is concave on [0,1]. On (0,1),

h_k''(z)=[k-(1-z)^(-3/2)]/(4*z^(3/2))<=0.

Continuity supplies the endpoints. Jensen then gives

h_k(z1)+h_k(z2)<=sqrt(2t-t^2)-k*sqrt(2t).

Thus the complete two-marked-face score has the global upper support

M2(k)=max( max_[0,1]{t+sqrt(2t-t^2)-k*sqrt(2t)},
           max_[1,2]{(t+1)*sqrt(2t-t^2)-k*sqrt(2t)} ).

It follows for every actual two-marked triangle, including degeneracies by continuity,

area/r^2+anchor1/r^2+anchor2/r^2 <= M2(k)+k*(x1+x2),

where each actual marked length is 2r*xi. This support does not assume equal marked edges. The separate upper bounds and Jensen happen to be sharp for an isosceles family on the second interval. Exact maximization of the displayed one-dimensional function, or a certified partition into closed intervals, provides an acceptance certificate.

## The stronger bound for an actual all-boundary ear

For an all-boundary face, every center c has norm at least 1-r, because its assigned Voronoi cell meets the unit circle. The face's common Voronoi point p satisfies |c-p|<=r and lies in the unit disk. Its norm t is positive: otherwise all these centers would have norm at most r, contrary to 1-r>r. With u=p/t,

c dot u >= (|c|^2+t^2-r^2)/(2t)
          >= (1-2r+t^2)/(2t) >= sqrt(1-2r).

The upper projection is one. Every center also belongs to B(p,r), so their width in the perpendicular direction is at most 2r. A triangle in a rectangle of width 2r and height 1-sqrt(1-2r) has area at most r*(1-sqrt(1-2r)). Therefore its normalized area is at most

w(r)=(1-sqrt(1-2r))/r.

For r=.113081, exact squaring verifies w(r)<1.065. Every anchor contributes at most 1/2. Put k=.24. The following deliberately simple score support then covers all t=z1+z2:

* t<=1: Delta<=t, anchor1+anchor2<=1, and sqrt(z1)+sqrt(z2)>=sqrt(t). The function t-k*sqrt(t) is convex, so its maximum on [0,1] is 1-k=.76. The complete score is at most 1.76.
* 1<=t<=1.03: Delta<=t<=1.03, anchors total<=1, and the marked half-length sum is at least one. The complete score is at most 1.79.
* t>=1.03: Delta<=w<1.065, anchors total<=1, and sqrt(z1)+sqrt(z2)>=1+sqrt(t-1)>=1+sqrt(.03). The complete score is less than 2.065-.24*(1+sqrt(.03))<1.79. The last strict inequality is equivalent to sqrt(.03)>7/48, checked by squares.

Thus for every actual all-boundary two-marked ear at this radius,

area/r^2+anchor1/r^2+anchor2/r^2-k*(x1+x2) <= 179/100.

The same bound is valid at any radius with w(r)<1.065. This cap is specific to actual boundary centers. It must not be applied to arbitrary two-marked triangles whose vertices need not lie in the boundary annulus. In the ear-aware budget below, it can replace M2(k) for every counted ear.

## Incidence identities with e boundary ears

Assume a straight center triangulated disk with B>=4 boundary vertices and m<=100, no all-boundary face having exactly one marked boundary edge, and no three-marked face. Allow unmarked all-boundary faces and e two-marked ears. Then ordinary one-marked faces number B-2e, ears number e, and unmarked faces number 2m-2B-2+e. Each ordinary marked face has an interior apex. Let q_v count such ordinary marked faces at interior vertex v, let d_v be its full degree, and let U count all unmarked boundary-angle occurrences. Let Gamma sum all ordinary marked apex angles.

Counting corners once gives

sum q_v=B-2e,
sum(d_v-6)=B-6+e-U,
sum unmarked BC angles=Gamma+(e-2)*pi.

Indeed total corners are 3F with F=2m-B-2; ordinary marked faces supply 2(B-2e) boundary corners, ears supply 3e, and unmarked faces supply U. Subtracting six times the m-B interior vertices yields the degree identity. The marked boundary-angle sum is (B-e)*pi-Gamma; subtract this from the polygon's (B-2)*pi angle sum to obtain the last identity. Neither convexity of the boundary chain nor chordlessness is required.

If a complete interior fan had no unmarked angle, it would consist entirely of ordinary marked faces. Its closed cyclic boundary-neighbor edges would then be the full boundary cycle, so q_v=B. Thus a separately established q_v<B still implies d_v-q_v>0.

## Using an existing vertex dual without repeated area charges

Apply the full-domain unmarked linear-score support once per unmarked triangle, with interior coefficient lambda_v and boundary coefficient -lambda_B. Apply the ordinary marked-face support with coefficient lambda_v+lambda_B once per ordinary marked face. Apply M2(k) once per ear. If the same vertex table satisfies

q*[C(lambda_v+lambda_B)-C(0)]-lambda_v*(6-d+q)*pi/3+(d-q)*lambda_v^2/(4c)
 <= beta*q+eta*(d-6),

and the nonsymmetric boundary lens proof pays the same common k per marked boundary edge, the previous e=0 total-area upper bound receives exactly the additional normalized term

e*[A-2*C(0)+M2(k)-2*beta+eta+lambda_B*pi].

The boundary length potential still has B terms because each ear contributes two marked boundary edges. The extra lambda_B*pi comes from the ear-aware boundary-angle identity. This formula is an identity in the accounting, not a claim that the bracket is nonpositive. If the bracket is positive, e must be explicitly optimized or separately excluded. No ear can be silently dropped.

For complete rigor, the full proof must still verify every current-radius geometric premise, corner coefficient range, all integer (q,d,U,e) cases, and the nonsymmetric length-potential support. Those global checks are not provided by this local extension.
