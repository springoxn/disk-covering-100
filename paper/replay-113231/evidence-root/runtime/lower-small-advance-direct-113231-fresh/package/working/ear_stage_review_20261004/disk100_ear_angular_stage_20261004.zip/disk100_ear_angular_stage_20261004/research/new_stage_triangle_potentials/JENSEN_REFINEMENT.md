# Jensen refinement of the maximizing-point curvature

This is a strict strengthening of the global linear-score support proved in
`PROOF.md`. That frozen proof and its original certificate remain valid as
written. The new constant still applies through the global score maximizer,
not as an area-loss coefficient at every actual triangle.

Use the notation of that proof, with \(L\le1/2\), \(\sum\mu_i=0\), and the
unique acute maximizing point satisfying

\[
 \cos(2\alpha_i)=\nu-\mu_i,\quad
 \sum_i\arccos(\nu-\mu_i)=2\pi,
 \quad -1/2+\min\mu\le\nu\le-1/2+\max\mu.
\]

The original bracket shows that all three arccosine arguments are in
\([-1,0]\). On this interval \(\arccos\) is convex, because

\[
 (\arccos x)''=-\frac{x}{(1-x^2)^{3/2}}\ge0
 \qquad(-1<x<0),
\]

with the closed-endpoint convexity following by continuity. Their mean is
\(\nu\). Jensen therefore yields

\[
 2\pi=\sum_i\arccos(\nu-\mu_i)\ge3\arccos\nu,
 \qquad\boxed{\nu\ge-1/2}.                          \tag{J1}
\]

Put \(m=\max_i\mu_i\ge0\). The maximum minus the average of three numbers
of range \(L\) is at most \(2L/3\), so \(m\le2L/3\). Consequently,

\[
 -1/2-m\le\cos(2\alpha_i)\le0,
 \qquad \sin(2\alpha_i)\ge
 \widetilde c_\mu:=\sqrt{1-(1/2+m)^2}
 \ge\widetilde c_L:=\sqrt{1-(1/2+2L/3)^2}.            \tag{J2}
\]

The equilateral angle and all maximizing angles belong to this same interval
(\(\cos(2a)=-1/2\)). As in the main proof, their straight segment does too.
Integrating the exact tangent Hessian and completing the square proves the
following support on **the whole closed angle simplex**:

\[
 \boxed{f(\alpha)+\sum_i\lambda_i(\alpha_i-\pi/3)
 \le A+\frac{\sum_i\mu_i^2}{4\widetilde c_\mu}
 \le A+\frac{\sum_i\mu_i^2}{4\widetilde c_L}.}        \tag{J3}
\]

One may replace \(\sum\mu_i^2\) by \(\sum\lambda_i^2\) as a weaker budget.
The common-potential shift rule is unchanged. Unlike the initial constant,
the refined constant is strictly positive at the closed range endpoint:
\(\widetilde c_{1/2}=\sqrt{11}/6\). This conclusion uses the same strictly
acute global localization already proved at \(L=1/2\); no new boundary
assumption is introduced.

Useful exact rational corollaries are

\[
 \begin{array}{c|c|c|c}
 \text{range guard}&\widetilde c_L&\text{safe rational }c
            &\text{penalty coefficient }1/(4c)\\ \hline
 L\le1/10&\sqrt{611}/30&41/50&25/82\\
 L\le1/5&\sqrt{539}/30&77/100&25/77\\
 L\le1/2&\sqrt{11}/6&11/20&5/11
 \end{array}
\]

In particular the degree-budget route at range \(1/5\) may use \(c=77/100\)
in its **linear-score support**, improving its former \(c=7/10\).

Run `python3 research/new_stage_triangle_potentials/verify_jensen.py`. The
standard-library exact rational certificate verifies these square comparisons,
range/centering guards and the three-entry maximum-minus-mean relation through
its exact algebraic formula. It also includes range \(1/2\) with positive
curvature and rejects out-of-range and floating inputs. The continuous Jensen
step is proved in (J1), not inferred from samples. No covering radius is claimed.
