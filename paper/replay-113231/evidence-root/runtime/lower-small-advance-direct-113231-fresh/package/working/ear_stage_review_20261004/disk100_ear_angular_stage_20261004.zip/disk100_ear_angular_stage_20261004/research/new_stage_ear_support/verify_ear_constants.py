#!/usr/bin/env python3
"""Exact constants for the actual all-boundary ear support. Local lemma only."""
from fractions import Fraction as Q
from pathlib import Path
import importlib.util,json

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('ear_interval',ROOT/'coupled_edges'/'verify_support.py')
v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)

def enc(q):return [q.numerator,q.denominator]
def verify():
    R=Q(113081,10**6);wcap=Q(213,200)
    lower=1-wcap*R
    assert lower>0 and lower*lower<1-2*R
    assert Q(7,48)**2<Q(3,100)
    assert Q(2065,1000)-Q(6,25)*(1+Q(7,48))==Q(179,100)
    assert Q(2065,1000)-Q(1,5)*(1+Q(1,5))<Q(46,25)
    assert Q(1,5)**2==Q(1,25)
    rows=[]
    for k,earcap in [(Q(6,25),Q(179,100)),(Q(1,5),Q(46,25))]:
        y=(-(1-k)+v.I((1-k)**2+32).sqrt())/8
        x=(1-y*y).sqrt()
        C0=x*(1+2*y-k)
        assert C0.a>1
        A=3*v.I(3).sqrt()/4
        coefficient=A-2*C0+earcap
        assert coefficient.b<0
        rows.append(dict(k=enc(k),earcap=enc(earcap),C0=C0.enc(),baseline_ear_coefficient=coefficient.enc()))
    # Original localized angle-potential tables: all three ear coefficients
    # are nonpositive at every B; the B-specific global premises are separate.
    data=json.loads((ROOT/'new_stage_degrees_localized'/'rational_potentials.json').read_text())
    C0=rows[0]['C0'];CI=v.I(Q(*C0[0]),Q(*C0[1]));A=3*v.I(3).sqrt()/4
    angular=[]
    assert len(data)==3
    for record in data:
        beta=Q(record['beta_numerator'],10**6);eta=Q(record['eta_numerator'],10**6)
        lb=Q(record['lambda_boundary'])
        coefficient=A-2*CI+Q(179,100)-2*beta+eta+lb*v.PI
        assert coefficient.b<0
        angular.append(dict(lambda_boundary=enc(lb),beta=enc(beta),eta=enc(eta),ear_coefficient=coefficient.enc()))
    return dict(status='PASS_LOCAL_EAR_CONSTANTS',radius=enc(R),slab_w_cap=enc(wcap),
                strict_slab_square_margin=enc(1-2*R-lower*lower),baseline=rows,
                original_localized_table_ear_coefficients=angular,
                scope='Analytic proof in PROOF.md establishes the local support; these exact checks verify its constants. No new global covering radius is declared.')

if __name__=='__main__':
    result=verify();Path(__file__).with_name('ear_constants_certificate.json').write_text(json.dumps(result,indent=2)+'\n')
    print(result['status'])
    for row in result['baseline']:print('k',Q(*row['k']),'baseline ear coefficient upper',Q(*row['baseline_ear_coefficient'][1]))
    for row in result['original_localized_table_ear_coefficients']:print('lambdaB',Q(*row['lambda_boundary']),'ear coefficient upper',Q(*row['ear_coefficient'][1]))
