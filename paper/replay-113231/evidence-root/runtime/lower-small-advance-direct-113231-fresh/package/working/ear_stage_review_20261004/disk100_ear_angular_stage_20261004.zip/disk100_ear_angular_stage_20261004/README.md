# Ear-aware exact angular support checkpoint

This package gives the local analytic accounting and same-radius conditional exact checks requested for independent review. It does not claim a new complete global lower bound or exact optimality. The independently audited global baseline at freezing is .11306 < r_D(100) <= .1155018241946.

At R=113081/1000000, B32..35, the refined support allows all q2 ears and unmarked all-boundary faces. Required current-radius premises are an actual straight Delaunay triangulated disk, no q1 marked all-boundary face, and interior ordinary-marked incidence q_v<=3. Those prerequisites and other B cases are being independently integrated outside this checkpoint.

Definitions and the ear-aware incidence/score derivation are in research/new_stage_ear_support/PROOF.md. All ordinary potential support and nonsymmetric per-boundary-edge length compensation proofs are included. The degree script records exact Fraction intervals, all three U branches, all 387 (q,d) types per branch, and negative per-ear coefficients. Decimal displays only summarize exact rational acceptance.

Run python3 run_all.py with assertions enabled. Python standard library only. Sources are original read-only imports or newly authored local mathematics; this is a frozen copy of the indicated files.
