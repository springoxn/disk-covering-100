#!/usr/bin/env python3
"""Exact constants and guards for the Jensen-refined global score support."""
from fractions import Fraction as Q
from pathlib import Path
import json
from verify_localization import I,PI,A,guard,require

def refined_guard(potentials):
 # Preserve frozen initial guards: this uses localization at the closed L=.5,
 # but does NOT request the initial zero-curvature quadratic constant there.
 L,bar,mu,_=guard(potentials)
 m=max(mu)
 # 3m=3 max(lambda)-sum(lambda) = sum(max(lambda)-lambda).
 top=max(potentials)
 require(3*m==sum((top-z for z in potentials),Q(0)),'maximum-minus-mean identity failed')
 require(0<=m<=2*L/3,'three-coefficient centered maximum range bound failed')
 c_mu=I(1-(Q(1,2)+m)**2).sqrt()
 c_range=I(1-(Q(1,2)+2*L/3)**2).sqrt()
 require(c_mu.a>0 and c_range.a>0,'Jensen refinement needs positive curvature')
 return L,bar,mu,m,c_mu,c_range

def qr(v):return [v.numerator,v.denominator]

def verify():
 rows=[]
 for L,c in [(Q(1,10),Q(41,50)),(Q(1,5),Q(77,100)),(Q(1,2),Q(11,20))]:
  sq=1-(Q(1,2)+2*L/3)**2
  margin=sq-c*c
  require(margin>0,'rational uniform curvature exceeds exact curvature')
  rows.append(dict(max_potential_range=qr(L),exact_curvature_squared=qr(sq),safe_rational_curvature=qr(c),squared_comparison_margin=qr(margin),linear_score_penalty_coefficient=qr(1/(4*c))))
 samples=[]
 # Both configurations attaining m=2L/3 and asymmetric triples are covered.
 for values in [(Q(0),)*3,(Q(-1,20),Q(-1,20),Q(1,20)),(Q(-1,10),Q(0),Q(1,10)),(Q(-1,4),Q(-1,4),Q(1,4)),(Q(-1,4),Q(0),Q(1,4)),(Q(10**20),)*3]:
  L,bar,mu,m,c_mu,c_range=refined_guard(values)
  norm2=sum((v*v for v in mu),Q(0))
  samples.append(dict(potentials=[qr(z) for z in values],range=qr(L),common_shift=qr(bar),centered_maximum=qr(m),centered_norm2=qr(norm2),potential_specific_curvature=c_mu.enc(),range_uniform_curvature=c_range.enc(),potential_specific_support_penalty=(I(norm2)/(4*c_mu)).enc()))
 rejected=0
 for bad in [(Q(0),Q(0),Q(501,1000)),(0.0,Q(0),Q(0)),(Q(0),Q(0))]:
  try:refined_guard(bad)
  except ValueError:rejected+=1
 require(rejected==3,'refined guards did not reject all invalid inputs')
 return dict(status='PASS',scope='Jensen-refined global linear-score support, not a stronger actual-angle area quadratic and not a covering radius.',jensen_nu_lower=[-1,2],closed_max_potential_range=[1,2],uniform_corollaries=rows,samples=samples,rejected_negative_guards=rejected)

if __name__=='__main__':
 result=verify();Path(__file__).with_name('jensen_certificate.json').write_text(json.dumps(result,indent=2)+'\n')
 print('PASS: Jensen-refined curvature guards including range=.5.')
 print('PASS: range<=.2 supports exact rational c=.77, range<=.1 supports c=.82.')
 print('NOT CERTIFIED: any covering radius or all-actual-angle strong curvature.')
