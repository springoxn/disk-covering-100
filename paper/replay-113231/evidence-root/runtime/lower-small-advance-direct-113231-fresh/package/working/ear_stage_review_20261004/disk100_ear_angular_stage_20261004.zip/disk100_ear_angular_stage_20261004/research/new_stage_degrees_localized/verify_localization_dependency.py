#!/usr/bin/env python3
"""Standard-library rational checks for the all-angle linear-support lemma.
The continuous localization and curvature proof is in PROOF.md.
This certifies a support inequality, not an actual-angle quadratic bound.
"""
from fractions import Fraction as Q
from pathlib import Path
from math import isqrt
import json
SCALE=10**35

class I:
 """Rational intervals, rounded outward to 35 decimal places."""
 def __init__(self,a,b=None):
  if isinstance(a,I):self.a,self.b=a.a,a.b;return
  a=Q(a);b=a if b is None else Q(b)
  require(a<=b,'invalid interval')
  self.a=Q(a.numerator*SCALE//a.denominator,SCALE)
  self.b=Q(-((-b.numerator*SCALE)//b.denominator),SCALE)
 def __add__(x,y):
  y=I(y);return I(x.a+y.a,x.b+y.b)
 __radd__=__add__
 def __neg__(x):return I(-x.b,-x.a)
 def __sub__(x,y):return x+-I(y)
 def __rsub__(x,y):return I(y)+-x
 def __mul__(x,y):
  y=I(y);v=[x.a*y.a,x.a*y.b,x.b*y.a,x.b*y.b]
  return I(min(v),max(v))
 __rmul__=__mul__
 def __truediv__(x,y):
  y=I(y);require(y.a*y.b>0,'zero divisor interval')
  return x*I(1/y.b,1/y.a)
 def __rtruediv__(x,y):return I(y)/x
 def sqrt(x):
  require(x.a>=0,'negative square-root interval')
  la=isqrt(x.a.numerator*SCALE*SCALE//x.a.denominator)
  ub=isqrt(x.b.numerator*SCALE*SCALE//x.b.denominator)+1
  a,b=Q(la,SCALE),Q(ub,SCALE)
  require(a*a<=x.a and b*b>x.b,'square-root enclosure failed')
  return I(a,b)
 def enc(x):return [[x.a.numerator,x.a.denominator],[x.b.numerator,x.b.denominator]]

def require(x,msg):
 if not x:raise ValueError(msg)

def atan_reciprocal(q,N=60):
 x=Q(1,q)
 v=sum(((-1)**j*x**(2*j+1)/Q(2*j+1) for j in range(N)),Q(0))
 e=(-1)**N*x**(2*N+1)/Q(2*N+1)
 return I(min(v,v+e),max(v,v+e))

PI=16*atan_reciprocal(5)-4*atan_reciprocal(239)
require(Q(3)<PI.a<PI.b<Q(22,7),'Machin pi bounds failed')
A=3*I(3).sqrt()/4

def guard(potentials,quadratic=False):
 require(len(potentials)==3 and all(type(x) is Q for x in potentials),'use three exact rational potentials')
 L=max(potentials)-min(potentials)
 require(L<=Q(1,2),'all-angle acute localization requires potential range <= 1/2')
 if quadratic:require(L<Q(1,2),'positive quadratic curvature requires range < 1/2')
 bar=sum(potentials,Q(0))/3
 mu=[x-bar for x in potentials]
 require(sum(mu,Q(0))==0,'centering failed')
 c=(I(1)-(Q(1,2)+L)*(Q(1,2)+L)).sqrt()
 return L,bar,mu,c

def verify():
 root3=I(3).sqrt()
 # Nonacute positive-deviation branch maximum occurs at theta=pi/2 or pi.
 margin_positive90=A-(1+PI/12)
 margin_positive180=A-PI/3
 # Negative-deviation branch sin(2t) tangent at pi/6.
 margin_negative=A-(root3/2+PI/8)
 require(all(z.a>0 for z in [margin_positive90,margin_positive180,margin_negative]),'global nonacute exclusion margin failed')
 # P_L(c)=2c^2+c-1+L. Its vertex is -1/4; P'_L=4c+1.
 def poly(c,L):return 2*c*c+c-1+L
 require(poly(Q(-1),Q(0))==0 and poly(Q(-1),Q(1,2))==Q(1,2),'P(-1)=L failed')
 require(poly(Q(-1,4),Q(1,2))==Q(-5,8)<0,'P(vertex) maximum failed')
 require(poly(Q(0),Q(1,2))==Q(-1,2)<0,'P(0) maximum failed')
 require(4*Q(-1,4)+1==0 and 4*Q(-1)+1<0 and 4*Q(0)+1>0,'polynomial monotonicity endpoints failed')
 # Exact .8 curvature from cos(2alpha) in [-.6,-.4].
 require(1-Q(3,5)**2==Q(4,5)**2,'range .1 curvature is not exactly .8')
 samples=[]
 for values in [(Q(0),Q(0),Q(0)),(Q(123,1000),)*3,(Q(-1,20),Q(0),Q(1,20)),(Q(-1,8),Q(0),Q(1,8)),(Q(-1,4),Q(0),Q(1,4))]:
  L,bar,mu,c=guard(values)
  norm2=sum((v*v for v in mu),Q(0))
  require(norm2==sum((v*v for v in values),Q(0))-3*bar*bar,'common-shift squared norm failed')
  penalty=None
  if L<Q(1,2):
   require(c.a>0,'positive curvature guard failed')
   penalty=(I(norm2)/(4*c)).enc()
  samples.append(dict(potentials=[[z.numerator,z.denominator] for z in values],range=[L.numerator,L.denominator],common_shift=[bar.numerator,bar.denominator],centered_norm2=[norm2.numerator,norm2.denominator],curvature=c.enc(),centered_support_penalty=penalty))
 rejects=0
 for bad,quad in [((Q(0),Q(0),Q(501,1000)),False),((Q(-1,4),Q(0),Q(1,4)),True),((0.0,Q(0),Q(0)),False)]:
  try:guard(bad,quad)
  except ValueError:rejects+=1
 require(rejects==3,'range/type/curvature negative checks failed')
 universal_c=9*root3/(8*PI*PI)
 require(Q(4,5)>4*universal_c.b,'new curvature did not exceed four times old universal c')
 return dict(status='PASS',scope='Global support of every angle triple for potential range <=1/2, with localized quadratic support for range <1/2. NOT a strengthened global actual-angle quadratic area bound, and NOT a new covering radius.',pi_enclosure=PI.enc(),sqrt3_enclosure=root3.enc(),nonacute_margins={'positive_branch_90':margin_positive90.enc(),'positive_branch_180':margin_positive180.enc(),'negative_branch':margin_negative.enc()},derivative_polynomial_coefficients_low_to_high=[[-1,1],[1,1],[2,1]],derivative_polynomial_vertex=[-1,4],range_1_over_10_exact_curvature=[4,5],uniform_unshifted_penalty_coefficient_at_range_point1=[5,16],samples=samples,negative_guards_rejected=rejects)
if __name__=='__main__':
 res=verify();Path(__file__).with_name('localization_certificate.json').write_text(json.dumps(res,indent=2)+'\n')
 print('PASS: all nonacute/degenerate global maximizers excluded for potential range <=1/2.')
 print('PASS: range <=1/10 has exact localized c=4/5; common shift and range guards verified.')
 print('PASS: rejecting excessive range, zero-curvature use and floating-point inputs.')
 print('NOT CERTIFIED: f <= A-cq for every actual angle triple, or a covering radius.')
