# Exact definitions for the ear-aware checkpoint

The working radius is R=113081/1000000. A=3sqrt(3)/4, k=6/25, c=3/4, a=pi/3. U is the number of unmarked boundary-angle occurrences, not the number of faces or boundary vertices. e is the number of all-boundary two-marked ear faces. Every other marked face is assumed to have exactly one boundary edge and an interior apex; those q1-all-boundary exceptions must be excluded geometrically at the same R.

For an ordinary marked face with marked length 2Rx and actual interior apex gamma, the joint ordinary-face plus boundary-anchor score obeys

area/R^2+anchor/R^2+l*gamma <= C(l)+k*x,

where y_l=[-(1-k)+sqrt((1-k)^2+32-16l)]/8, x_l=sqrt(1-y_l^2), and

C(l)=max{x_l*(1+2y_l)+l*asin(x_l)-k*x_l, 1+max(0,l*pi)}.

The script checks k-3<l<2 and 0<y_l<1 for every selected l. In particular C0=C(0), enclosed independently as approximately 1.5692122490175917. Ordinary marked faces are counted once. Each ear instead receives the actual-annulus support M2=179/100, so its two marked boundary edges still contribute k*(x1+x2). This is why the same nonsymmetric lens compensation pays k once for each of the B boundary edges, even in the presence of ears.

Each unmarked triangle receives one global linear score support

area/R^2+sum p_i*(alpha_i-a) <= A+sum p_i^2/(4c).

Interior corner coefficient is lambda_v in [-19/100,1/20]; boundary corner coefficient is -lambda_B in the same interval. Their range is at most 6/25. The Jensen refinement gives curvature sqrt(1-(1/2+2*(6/25)/3)^2)>3/4, so c=3/4 is safe. This is a linear score support on the full angle simplex; it is not an assertion of strong actual-angle quadratic loss.

For each interior type (q,d), q counts ordinary marked apex occurrences, n=d-q>0 counts unmarked corners, and d is the full interior degree. The three frozen records verify all 387 types with 0<=q<=3 and max(3,q+1)<=d<=99. Each lambda_v is explicitly listed as an integer divided by 10^6 in rational_potentials.json. The type inequality is

q*[C(lambda_v+lambda_B)-C0]-lambda_v*(6-d+q)*a+n*lambda_v^2/(4c)
 <= beta*q+eta*(d-6).

The exact scalar duals are:

| U branch | lambda_B | beta | eta |
|---|---:|---:|---:|
| U<=22 | 0 | -2882/10^6 | -48582/10^6 |
| U=23 | 19/500 | 31964/10^6 | -54350/10^6 |
| U>=24 | 19/250 | 67113/10^6 | -60106/10^6 |

The ear-aware incidence identities, proved in research/new_stage_ear_support/PROOF.md, are

sum q=B-2e; sum(d-6)=B-6+e-U; sum unmarked BC angles=Gamma+(e-2)*pi.

Substituting them into the summed once-per-face supports gives the normalized extra angular term

G_B(U)=B*beta+eta*(B-6-U)-lambda_B*(2*pi+U*a)+U*lambda_B^2/(4c),

and the extra ear term

e*E, where E=A-2*C0+179/100-2*beta+eta+lambda_B*pi.

The three exact Fraction interval checks give E upper bounds summarized as -.0922043923585255, -.04828387152211336, -.004957350685701212. Thus every e>=0 improves the inequality; e=0 is the weakest case. No upper bound on e is needed for this deduction. The ordinary unmarked all-boundary faces are included in the unmarked support and all their angles carry the boundary coefficient. No chordlessness is assumed.

The common-k nonsymmetric boundary compensation, proved in the included coupled_edges/PROOF.md, supplies the area baseline

L_B=R^2*[(198-2B)*A+B*(C0+k*sin eta0)]+B*H_R(2*pi/B),

where s=sin(pi/B), h=sqrt(R^2-s^2), sin eta0=s*(cos(pi/B)-h)/R and H_R(theta)=sin(theta/2)*sqrt(R^2-sin^2(theta/2))+(theta-sin theta)/2. The acceptance checker explicitly rechecks both short-arc support endpoints; equal arcs enter only as a universal concave upper support, not as a restriction on actual centers or arc lengths.

The necessary area condition is therefore pi<=L_B+R^2*G_B(U)+R^2*e*E. The first branch's U coefficient is positive, so U=22 is the weakest U<=22 case; the last branch's coefficient is negative, so U=24 is weakest for U>=24. All three final deficits are strictly positive for each B=32,33,34,35. The smallest is .00002796832028318462, at B33/U23; the exact rational interval is saved in earaware_allcounts_certificate.json.

This checkpoint proves those conditional branches with all ears allowed. Complete global optimality and even a new universal lower bound still require the same-radius geometric/count bridge and every other B case. This checkpoint does not claim either completion.
