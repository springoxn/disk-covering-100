#!/usr/bin/env python3
from pathlib import Path
import subprocess,sys
D=Path(__file__).resolve().parent
if not __debug__:raise RuntimeError('Assertions must be enabled')
for p in ['research/new_stage_triangle_potentials/verify_localization.py','research/new_stage_triangle_potentials/verify_jensen.py','research/new_stage_ear_support/verify_ear_constants.py','research/new_stage_degrees_refined/verify_earaware_allcounts.py']:
 subprocess.run([sys.executable,p],cwd=D,check=True)
print('ALL LOCAL EAR-AWARE CHECKPOINT CHECKS PASSED',flush=True)
