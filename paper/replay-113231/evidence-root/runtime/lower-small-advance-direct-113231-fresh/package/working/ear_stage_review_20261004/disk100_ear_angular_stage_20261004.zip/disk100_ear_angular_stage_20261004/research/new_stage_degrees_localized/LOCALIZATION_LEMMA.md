# A strong global support for three independent angle potentials

Status: proved local analytic lemma, with a standard-library exact rational certificate.
It supplies a global linear-score upper bound. It does **not** assert a stronger
quadratic area loss at every actual triangle, and does not itself establish a new
covering radius.

## Statement

Let

\[
 \mathcal T=\{(\alpha_1,\alpha_2,\alpha_3):\alpha_i\ge0,
                  \alpha_1+\alpha_2+\alpha_3=\pi\},\qquad
 f(\alpha)=2\prod_i\sin\alpha_i,
 \quad a=\pi/3,\quad A=3\sqrt3/4.
\]

These include all degenerate angle triples. For a triangle of circumradius at
most \(r\), its area is at most \(r^2 f(\alpha)\). Let arbitrary real potentials
\(\lambda_i\) have range \(L=\max_i\lambda_i-\min_i\lambda_i\), and put
\(\bar\lambda=(\lambda_1+\lambda_2+\lambda_3)/3\),
\(\mu_i=\lambda_i-\bar\lambda\).

If \(L\le1/2\), the maximum of

\[
 S_\lambda(\alpha)=f(\alpha)+\sum_i\lambda_i(\alpha_i-a)
\]

on the **whole** compact simplex \(\mathcal T\) is attained at a unique,
strictly acute triple. If \(L<1/2\), define

\[
 c_L=\sqrt{1-(1/2+L)^2}>0.
\]

Then for every angle triple, with no acuteness hypothesis on that triple,

\[
 \boxed{S_\lambda(\alpha)
 \le A+\frac{\sum_i\mu_i^2}{4c_L}
 \le A+\frac{\sum_i\lambda_i^2}{4c_L}.}                 \tag{1}
\]

Consequently, for \(L\le1/10\), the completely explicit support is

\[
 \boxed{f(\alpha)+\sum_i\lambda_i(\alpha_i-a)
 \le A+\frac5{16}\sum_i(\lambda_i-\bar\lambda)^2
 \le A+\frac5{16}\sum_i\lambda_i^2.}                  \tag{2}
\]

The uncentered score \(f+\sum\lambda_i\alpha_i\) adds exactly
\(\pi\bar\lambda\) to the right side. A common potential can be arbitrarily
large; only the **range** is restricted. A convenient sufficient guard for (2)
is that all three coefficients lie in \([-1/20,1/20]\).

## 1. Excluding every nonacute and degenerate maximizer

Write \(x_i=\alpha_i-a\). Since there are exactly three entries and
\(\sum x_i=0\),

\[
 \sum_{x_i>0}x_i=\max_i|x_i|
 =\max\{\max_i\alpha_i-a,\ a-\min_i\alpha_i\}=:d.
\]

Subtracting the smallest potential, the centered linear score satisfies

\[
 \sum_i\lambda_i x_i\le L\sum_{x_i>0}x_i=Ld.        \tag{3}
\]

Suppose the triple is nonacute, so some angle is at least \(\pi/2\). There
are two possible choices of the largest absolute deviation in (3).

**Positive deviation.** Put \(\theta=\max_i\alpha_i\ge\pi/2\). With this
angle fixed, the other two sine factors have maximum when their angles are
equal, so

\[
 f\le h(\theta):=\sin\theta(1+\cos\theta).
\]

The derivative of \(h(\theta)+L(\theta-a)\), in terms of
\(u=\cos\theta\in[-1,0]\), is

\[
 P_L(u)=2u^2+u-1+L.
\]

For \(0\le L\le1/2\), \(P_L(-1)=L\ge0\),
\(P_L(-1/4)=L-9/8<0\), and \(P_L(0)=L-1<0\).
The polynomial decreases on \([-1,-1/4]\) and increases on
\([-1/4,0]\). For \(L>0\), its only root in \([-1,0]\) changes the derivative
in \(\theta\) from negative to positive. For \(L=0\), the root is the endpoint
\(u=-1\) and the expression decreases throughout \((\pi/2,\pi)\).
In either case the maximum is at an endpoint.
Therefore

\[
 f+\sum_i\lambda_i x_i
 \le\max\{1+L\pi/6,\ 2L\pi/3\}
 \le\max\{1+\pi/12,\ \pi/3\}<A.                    \tag{4}
\]

**Negative deviation.** Put \(t=\min_i\alpha_i\). Nonacuteness forces
\(0\le t\le\pi/4\). If another angle \(\theta\ge\pi/2\), then
\(\theta\le\pi-t\), and

\[
 f=2\sin t\sin\theta\sin(t+\theta)\le\sin(2t).
\]

Indeed the derivative of the product of the last two sine factors is
\(\sin(2\theta+t)\le0\) in this interval, so the maximum occurs at
\(\theta=\pi/2\). Concavity of \(\sin(2t)\) on \([0,\pi/4]\) gives its
tangent at \(t=\pi/6\):

\[
 \sin(2t)\le\sqrt3/2+t-\pi/6.
\]

Using \(1-L\ge0\) and \(t\le\pi/4\),

\[
 \begin{aligned}
 f+\sum_i\lambda_i x_i
 &\le\sin(2t)+L(a-t)\\
 &\le\sqrt3/2+\pi(1+L)/12
 \le\sqrt3/2+\pi/8<A.                              \tag{5}
 \end{aligned}
\]

The equilateral triple has score exactly \(A\). Equations (4) and (5)
strictly exclude every nonacute triple from the global maximizer set. Every
boundary triple of \(\mathcal T\) is nonacute (one angle is zero and the
other two sum to \(\pi\)), so this also excludes all degenerate maxima.
The three strict universal margins are certified with exact rational bounds
for \(\pi\) and \(\sqrt3\) in `localization_certificate.json`.

## 2. Unique acute maximizer and its scalar parameter

On the angle-sum plane the exact trigonometric identity is

\[
 \sin(2\alpha_1)+\sin(2\alpha_2)+\sin(2\alpha_3)
 =4\sin\alpha_1\sin\alpha_2\sin\alpha_3,
 \qquad f=\tfrac12\sum_i\sin(2\alpha_i).             \tag{6}
\]

For any tangent vector \(v\) with \(\sum v_i=0\), its exact second derivative
is

\[
 D^2f[v,v]=-2\sum_i\sin(2\alpha_i)v_i^2.             \tag{7}
\]

This is strictly negative at acute triples for nonzero \(v\). The acute
simplex is convex, so the score is strictly concave there; the global
maximizer from Section 1 is unique. At that interior point the Lagrange
multiplier equations give

\[
 \cos(2\alpha_i)+\mu_i=\nu,\qquad
 \sum_i\arccos(\nu-\mu_i)=2\pi.                    \tag{8}
\]

The arccosine has its usual branch \([0,\pi]\), because the angles are acute.
The sum in (8) is strictly decreasing in \(\nu\). Its unique root satisfies

\[
 -1/2+\min_i\mu_i\ \le\nu\le\ -1/2+\max_i\mu_i. \tag{9}
\]

For example, at the lower bracket endpoint every argument is at most
\(-1/2\), so each arccosine is at least \(2\pi/3\); at the upper endpoint
each is at most \(2\pi/3\). The arguments lie in \([-1,0]\) whenever
\(L\le1/2\), so these endpoint evaluations are within the closed domain.
It follows that, at the maximizing triple,

\[
 -1/2-L\le\cos(2\alpha_i)\le-1/2+L.                \tag{10}
\]

For \(L<1/2\), this also encloses every maximizing angle in

\[
 \tfrac12\arccos(-1/2+L)\le\alpha_i
 \le\tfrac12\arccos(-1/2-L)<\pi/2.
\]

## 3. Integrating the localized curvature, then obtaining global support

The straight segment from the equilateral triple to the maximizing triple
stays inside the angle interval just displayed. On that segment,

\[
 \sin(2\alpha_i)\ge\sqrt{1-(1/2+L)^2}=c_L.
\]

Let the maximizing deviation be \(x_i=\alpha_i-a\). Equation (7), integrated
along the segment, together with zero equilateral tangent derivative, gives

\[
 f(\alpha^{\rm max})\le A-c_L\sum_i x_i^2.
\]

Completing the square now bounds the maximum score itself:

\[
 \begin{aligned}
 S_\lambda(\alpha^{\rm max})
 &\le A-c_L\|x\|^2+\mu\cdot x\\
 &=A+\frac{\|\mu\|^2}{4c_L}
       -c_L\left\|x-\frac\mu{2c_L}\right\|^2
 \le A+\frac{\|\mu\|^2}{4c_L}.
 \end{aligned}
\]

Every other triple has score no larger than this unique global maximum,
which proves (1) on the entire closed simplex. The weaker uncentered penalty
uses the exact identity
\(\sum\mu_i^2=\sum\lambda_i^2-3\bar\lambda^2\).
For \(L\le1/10\), \(c_L\ge\sqrt{1-(3/5)^2}=4/5\), proving (2).

## 4. Scope and safe use in a covering argument

The strong curvature is proved on the segment to a maximizing triangle for
the specified potentials. An arbitrary actual triangle can be obtuse or
degenerate; the inequality \(f\le A-(4/5)\sum(\alpha_i-a)^2\) is false for
such triples. At \((\pi,0,0)\), its right side is negative. What holds globally
is exactly the **linear-score support** (1) or (2).

Thus a global proof may choose one coefficient at each triangle corner,
apply (2) once to each unmarked triangle, and sum. No second independent
area-loss charge is being deducted. The geometric incidence identities and
the resulting total penalty budget must be justified separately by that
global proof. This file supplies neither those identities nor an improved
unit-disk covering bound.

## 5. Reproducible certificate

Run `python3 research/new_stage_triangle_potentials/verify_localization.py`.
The program uses only Python standard-library `Fraction` and integer square
roots. It encloses \(\pi\) using the alternating Machin formula and encloses
\(\sqrt3\) with checked squares, all with outward rational rounding. It
verifies the three strict nonacute margins, polynomial endpoint guards,
the exact \(4/5\) curvature, centering/common-shift identities, and rejection
of out-of-range coefficients, zero-curvature requests, and floating inputs.
The continuous inequalities and root monotonicity are proved above; the
script is a reproducible exact arithmetic certificate for their constants.
